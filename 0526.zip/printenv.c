#include<stdio.h>
#include<stdlib.h>

int main(int argc, char*argv[])
{
	char *ptr;

	ptr =getenv("HOME");
	printf("HOME = %sWn", ptr);
	
	ptr = getenv("SHELL");
	printf("SHELL = %sWn". ptr);

	ptr =getenv("PATH");
	printf("PATH =  %sWn", ptr);

	_exit(6);

}


