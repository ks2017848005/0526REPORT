#include<stdio.h>
int main(int argc, char **argv)
{
	FILE *fp = fopen("dum", "w");
	
	if(fp)
	{
		fprintf(fp, "HelloWn");
		fclose(fp);
	}
	else
		printf("fopen errorWn");

	return 0;

}
